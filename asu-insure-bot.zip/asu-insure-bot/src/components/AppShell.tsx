import TopNav from "./TopNav";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50">
      <TopNav />
      <main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
      <footer className="mx-auto max-w-6xl px-4 py-10 text-sm text-slate-500">
        <div className="border-t pt-6">
          This is a hackathon prototype for education and cost navigation, not medical advice.
        </div>
      </footer>
    </div>
  );
}
