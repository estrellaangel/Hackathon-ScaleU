import AppShell from "../components/AppShell";

import FeatureTiles from "../components/FeatureTiles";

import Link from "next/link";

export default function Home() {
  return (
    <AppShell>
      <section className="grid gap-8 md:grid-cols-2 items-center">
        <div className="space-y-5">
          <h1 className="text-4xl md:text-5xl font-bold leading-tight">
            Understand your insurance before you spend money
          </h1>

          <p className="text-slate-600">
            This is a hackathon prototype that helps students understand what their insurance
            covers, what it does not, and what their cheapest options are.
            You select your plan, explain your situation, and get plan-aware guidance
            in plain English. No diagnosis, just clarity and smarter decisions.
          </p>

          <div className="flex gap-3">
            <Link
              href="/chat"
              className="rounded-xl bg-black px-5 py-3 text-white text-sm"
            >
              Open the prototype
            </Link>
            <a
              href="#how"
              className="rounded-xl border px-5 py-3 text-sm"
            >
              See how it works
            </a>
          </div>

          <div className="text-xs text-slate-500">
            Emergency note: For severe or sudden symptoms, seek urgent medical care immediately.
          </div>
        </div>

        <div className="rounded-3xl border bg-white p-6 shadow-sm">
          <div className="text-sm text-slate-500">Preview</div>
          <div className="mt-2 text-lg font-semibold">Plan-based guidance</div>
          <div className="mt-3 grid gap-3">
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-xs text-slate-500">Step 1</div>
              <div className="font-medium">Pick your plan</div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-xs text-slate-500">Step 2</div>
              <div className="font-medium">Explain your situation</div>
            </div>
            <div className="rounded-2xl bg-slate-50 p-4">
              <div className="text-xs text-slate-500">Step 3</div>
              <div className="font-medium">Get options and savings</div>
            </div>
          </div>
        </div>
      </section>

      <div className="my-12" />

      <FeatureTiles />

      <div className="my-12" />

      <section
        id="how"
        className="rounded-3xl border bg-white p-6 shadow-sm space-y-3"
      >
        <h2 className="text-xl font-semibold">How it works</h2>
        <p className="text-slate-600">
          Select your insurance plan, ask a question, and the chatbot explains
          what is typically covered, what is not, and which care options
          are cheaper. The goal is clarity, not diagnosis.
        </p>
      </section>
    </AppShell>
  );
}
